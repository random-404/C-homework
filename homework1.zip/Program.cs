﻿using System;

namespace homework1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                double result = 0;
                Console.WriteLine("请输入第一个数字");
                double num1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("请输入运算符");
                string str = Console.ReadLine();

                Console.WriteLine("请输入第二个数字");
                double num2 = Convert.ToDouble(Console.ReadLine());

                switch (str)
                {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/":
                        if (num2 == 0)
                        {
                            Console.WriteLine("0不能为除数！");
                            break;
                        }
                        result = num1 / num2; break;
                }
                Console.WriteLine("得到的结果是" + result);
            }
        }
    }
}
