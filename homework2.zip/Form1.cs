﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework2
{
   
    public partial class Form1 : Form
    {
        private double num1;
        private double num2;
        private double result;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            num2 = double.Parse(textBox2.Text);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str = listBox1.Text;
            if (str == "+" )
            {
                result = num1 + num2;
            }
            else if (str == "-")
            {
                result = num1 - num2;
            }
            else if (str == "*")
            {
                result = num1 * num2;
            }
            else if (str == "/")
            {
                if (num2 == 0)
                {
                    Console.WriteLine("0不能作为除数");
                }
                else {
                    result = num1 / num2;
                }
                
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
           MessageBox.Show("得到的结果是" + result);
        }
    }
}
